51Degrees.mobi is supported by a �freemium� business model. All device
detection and redirection source code is licenced under the Mozilla
Public Licence 2 (MPL2) allowing free commercial use.

Lite device data is also licenced under MPL2, is free and embedded
into the assembly. It includes around 50 properties, associated
metadata, but does not contain devices released in the last 3 months. 

Premium device data is paid for on an annual subscription with prices
starting at less than $1 a day and includes the following additional
benefits.

1.	Weekly device data updates including all the latest devices, 
	browser and OS versions

2.	Over 50 extra properties (over 100 in total) including IsTablet,
	screen size in millimetres and detailed model, platform and browser
	information

3.	Option to enable automatic updates to ensure your web site is 
	always using the latest device data

4.	Metadata covering all 100+ properties

Find out more by visiting http://51degrees.mobi/Products/DeviceData

Thank you for installing 51Degrees.mobi.
